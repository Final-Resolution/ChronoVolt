# IV-22-VFD-Tube-Clock
IV-22 Vacuum Florescent Display (VFD)  tube clock.  

These are the PCB files for my IV-22 VFD Tube Clock project.

This clock uses 5 IV-22 VFD tubes and 1 IV-15 VFD tube. The IV-15 VFD tube can be swapped with a 3mm through-hole LED.

I've decided to not release the code or gerber files for now. You can look at the board pdf layers if you are curious about the PCB layout.

![IV-22 VFD Tube Clock V2 1](https://user-images.githubusercontent.com/23159547/157260526-ae6a7c27-cd16-4a35-99e7-9df18ec0d3e9.jpg)
